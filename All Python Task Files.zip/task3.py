# importing random module
import random
print("Welcome to Pop Chat")
print("One of our operators will be pleased to help you today")
# list that contains the name of chatbots
chatbot_names = ["Janice", "Fiona", "Arthur"]
# randomly selects one of the chatbot names
random_chatbot_name = random.choice(chatbot_names)
# list that contains random remarks for the user
remarks = ["Hmmm", "Oh yes, I see", "Tell me more", "This is interesting"]
# randomly selects one of the remarks
random_remarks = random.choice(remarks)
# ask user to input their email address
email_address = input("Please enter Your Poppleton email address : ").lower()
# selects the name part excluding the email address
name_only = email_address[:-10]
# condition to check wether the email entered by the user if certain or not
if email_address.count("@") == 1 and len(name_only) >= 2 and "@pop.ac.uk" in email_address:
    # name = email_address.split("@")[0]

    print(f"Hi, {name_only}! Thank You. Welcome to PopChat!")

    print(
        f"My name is {random_chatbot_name}, and it will be my Pleasure to help you.")

    question = input("-->").lower()
    # randomly selects any value between 0 to 10 so it gives 10% chance of giving network error
    error = range(0, 10)
    for i in error:
        if random.choice(error) == 1:
            print("****NETWORK ERROR**\n\n")
            break
        else:
            # if the user enters no string it enters this loop
            while question != "":
                # checks if the renetered string is library
                if "library" in question:
                    print("The library is closed today.")
                    question = input("-->").lower()
                elif "wifi" in question:
                    print("Wifi is excellent across the campus")
                    question = input("-->").lower()
                elif "coffee" in question:
                    print("Coffee Shop is open until 9pm this evening")
                    question = input("-->").lower()
                elif "deadline" in question:
                    print("Deadline has been extended for two working days")
                    question = input("-->").lower()
                elif "football" in question:
                    print(
                        "All the sports like Football, Basketball, Hockey, Cricket etc are availble to play.")
                    question = input("-->").lower()
                elif "beer" in question:
                    print(
                        "Beer, Wine, Whiskey or any other liquior item is not allowed inside college premises")
                    question = input("-->").lower()
                # if the user enter exit, bye, goodbye or help the program terminates
                elif "exit" in question or "bye" in question or "goodbye" in question or "help" in question:
                    print()
                    break
                # if the user enter no string
                else:
                    print(random_remarks)
                    question = input("-->").lower()
                break
            # if the user enters a string it enters this loop
            while question == "":
                # if the rentered value is empty
                if question == "":
                    print(random_remarks)
                    question = input("-->").lower()
                elif "library" in question:
                    print("The library is closed today.")
                    question = input("-->").lower()
                elif "wifi" in question:
                    print("Wifi is excellent across the campus")
                    question = input("-->").lower()
                elif "coffee" in question:
                    print("Coffee Shop is open until 9pm this evening")
                    question = input("-->").lower()
                elif "deadline" in question:
                    print("Deadline has been extended for two working days")
                    question = input("-->").lower()
                elif "football" in question:
                    print(
                        "All the sports like Football, Basketball, Hockey, Cricket etc are availble to play.")
                    question = input("-->").lower()
                elif "beer" in question:
                    print(
                        "Beer, Wine, Whiskey or any other liquior item is not allowed inside college premises")
                    question = input("-->").lower()
                elif "exit" in question or "bye" in question or "goodbye" in question or "help" in question:
                    print()
                    break

                    exit()
                # if the user enter a string that does not match any condition
                elif question != "":
                    print(random_remarks)
                    question = input("-->").lower()
                break
    print(f"Thanks, {name_only}, for using PopChat. See You Again Soon.")

else:
    exit()
