print("Stop! Who would cross the Bridge of Death")
print("Must answer these questions three, 'ere the other side he see.\n")
#asks the user to input the name
name = input("What is your name? ")
#condition to check if name is arthur
if("Arthur" in name or "arthur" in name):
    print("My liege! You may pass!")
else:
    #asks the user for quest
    quest = input("What is your quest? ")
    #condition to check is grail consists in name then runs the following question
    if("Grail" in quest or "grail" in quest):
        colour = input("What is your favourite colour? ")
        #check the first letter of the user input name and color
        if(name.lower()[0] == colour.lower()[0]):
            print("You may pass!")
        else:
            print("Incorrect! You must now face the Gorge of Eternal Peril.")
    else:
        print("Only those who seek the Grail may pass.")
