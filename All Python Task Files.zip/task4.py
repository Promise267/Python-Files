# importing operator for addition and substraction of corresponding data of multiple lists
import operator
print("\t\t\t\tLaliga 2022")
print("==============================================================================")
print("\t\t P\t W\t D\t L\t F\t A\t Diff\t Pts")
print("==============================================================================")

# creating a class called football


class Football:
    # creating a constructor to use the vairbles inside through out the methods of the class
    def __init__(self):
        self.team_list = []
        self.main_list = []
        self.listP = []
        self.listW = []
        self.listD = []
        self.listL = []
        self.listF = []
        self.listA = []
        self.listDiff = []
        self.listPts = []

    # creating a method to open the teams file, read it and append it to the team_list list
    def teams(self):
        with open('teams.txt', 'r') as t:
            for line in t:
                # adds each line of teams.txt file as data in a list
                self.team_list.append(line.strip())
    # creating a method to open the results file, read it and append it to the main_list list

    def result(self):
        with open('result.txt', 'r') as r:
            for line in r:
                # each line of the result.txt file is put into list as separate lists
                strip_lines = line.strip()
                # separates each data in a list by ','
                splitted_lines = strip_lines.split(',')
                # appends the list to the main_list list
                self.main_list.append(splitted_lines)

    # creating a method to count number of times each team has played
    def played(self):
        # initialising count value of different teams
        count_madrid = 0
        count_barcelona = 0
        count_valencia = 0
        count_atletico = 0
        count_socieadad = 0
        count_betis = 0
        count_villarreal = 0
        count_getafe = 0
        count_celta = 0
        count_athletic = 0
        # using for loop to read contents inside the main_list list
        for line in self.main_list:
            for i in line:
                if "Madrid" in i:
                    # appends the value by 1 if the loop reads madrid
                    count_madrid += 1
                if "Barcelona" in i:
                    count_barcelona += 1
                if "Valencia" in i:
                    count_valencia += 1
                if "Atletico" in i:
                    count_atletico += 1
                if "Socieadad" in i:
                    count_socieadad += 1
                if "Betis" in i:
                    count_betis += 1
                if "Villarreal" in i:
                    count_villarreal += 1
                if "Getafe" in i:
                    count_getafe += 1
                if "Celta" in i:
                    count_celta += 1
                if "Athletic" in i:
                    count_athletic += 1
        # appends the count value of number of times playes by different teams to listP list
        self.listP.append(count_madrid)
        self.listP.append(count_barcelona)
        self.listP.append(count_valencia)
        self.listP.append(count_atletico)
        self.listP.append(count_socieadad)
        self.listP.append(count_betis)
        self.listP.append(count_villarreal)
        self.listP.append(count_getafe)
        self.listP.append(count_celta)
        self.listP.append(count_athletic)

    def won(self):
        # creating an empty list called won to later add the team that won in each match
        won = []
        # intialising a as 0 for looping
        a = 0
        # loops till it reaches the last line of the txtfile
        while a < 45:
            # condition to check if the team in the zero index of list won
            if(self.main_list[a][1] > self.main_list[a][3]):
                won.append(self.main_list[a][0])
                # initialises a to check the next line for same condition
                a = a + 1
            # condition to check if the team in the second index of list won
            elif(self.main_list[a][3] > self.main_list[a][1]):
                won.append(self.main_list[a][2])
                # initialises a to check the next line for same condition
                a = a + 1
            # condtion if match ends in draw then no winner
            else:
                a = a + 1
                # initialises a to check the next line for same condition
                continue
        # counts the number of times each team won
        win_madrid = won.count("Madrid")
        win_barcelona = won.count("Barcelona")
        win_valencia = won.count("Valencia")
        win_atletico = won.count("Atletico")
        win_socieadad = won.count("Socieadad")
        win_betis = won.count("Betis")
        win_villarreal = won.count("Villarreal")
        win_getafe = won.count("Getafe")
        win_celta = won.count("Celta")
        win_athletic = won.count("Athletic")

        # appends the count value the listW list
        self.listW.append(win_madrid)
        self.listW.append(win_barcelona)
        self.listW.append(win_valencia)
        self.listW.append(win_atletico)
        self.listW.append(win_socieadad)
        self.listW.append(win_betis)
        self.listW.append(win_villarreal)
        self.listW.append(win_getafe)
        self.listW.append(win_celta)
        self.listW.append(win_athletic)

    def draw(self):
        # intialising a as 0 for looping
        a = 0
        # creating an empty list called draw to later add the team that end the match in draw
        draw = []
        # loops till it reaches the last line of the txtfile
        while a < 45:
            # condition to check if the teams have same score
            if(self.main_list[a][1] == self.main_list[a][3]):
                draw.append(self.main_list[a][0])
                draw.append(self.main_list[a][2])
                # initialises a to check the next line for same condition
                a = a + 1
            # if above condition does not match
            else:
                # initialises a to check the next line for same condition
                a = a + 1
                continue

        # counts the number of times each team had a draw
        draw_madrid = draw.count("Madrid")
        draw_barcelona = draw.count("Barcelona")
        draw_valencia = draw.count("Valencia")
        draw_atletico = draw.count("Atletico")
        draw_socieadad = draw.count("Socieadad")
        draw_betis = draw.count("Betis")
        draw_villarreal = draw.count("Villarreal")
        draw_getafe = draw.count("Getafe")
        draw_celta = draw.count("Celta")
        draw_athletic = draw.count("Athletic")

        # appends the count value of number of times playes by different teams to listP list
        self.listD.append(draw_madrid)
        self.listD.append(draw_barcelona)
        self.listD.append(draw_valencia)
        self.listD.append(draw_atletico)
        self.listD.append(draw_socieadad)
        self.listD.append(draw_betis)
        self.listD.append(draw_villarreal)
        self.listD.append(draw_getafe)
        self.listD.append(draw_celta)
        self.listD.append(draw_athletic)

    def loss(self):
        # intialising a as 0 for looping
        a = 0
        # creating an empty list called loss to later add the team that end the match in loss
        loss = []
        # loops till it reaches the last line of the txtfile
        while a < 45:
            # condition to check if the team in the zero index of list lost
            if(self.main_list[a][1] > self.main_list[a][3]):
                loss.append(self.main_list[a][2])
                # initialises a to check the next line for same condition
                a = a + 1
            # condition to check if the team in the second index of list lost
            elif(self.main_list[a][3] > self.main_list[a][1]):
                loss.append(self.main_list[a][0])
                # initialises a to check the next line for same condition
                a = a + 1
            # if no conditions matched
            else:
                # initialises a to check the next line for same condition
                a = a + 1
                continue
        # counts the number of times each team had a draw
        loss_madrid = loss.count("Madrid")
        loss_barcelona = loss.count("Barcelona")
        loss_valencia = loss.count("Valencia")
        loss_atletico = loss.count("Atletico")
        loss_socieadad = loss.count("Socieadad")
        loss_betis = loss.count("Betis")
        loss_villarreal = loss.count("Villarreal")
        loss_getafe = loss.count("Getafe")
        loss_celta = loss.count("Celta")
        loss_atheltic = loss.count("Athletic")

        # appends the count value of number of times playes by different teams to listP list
        self.listL.append(loss_madrid)
        self.listL.append(loss_barcelona)
        self.listL.append(loss_valencia)
        self.listL.append(loss_atletico)
        self.listL.append(loss_socieadad)
        self.listL.append(loss_betis)
        self.listL.append(loss_villarreal)
        self.listL.append(loss_getafe)
        self.listL.append(loss_celta)
        self.listL.append(loss_atheltic)

    def goals_for(self):
        # intialising each vairable for each while loop
        a = 0
        b = 0
        c = 0
        d = 0
        e = 0
        f = 0
        g = 0
        h = 0
        k = 0
        l = 0
        # creating each different empty list to add goals scored by each different team in each match
        goals_scored_madrid = []
        goals_scored_barcelona = []
        goals_scored_valencia = []
        goals_scored_atletico = []
        goals_scored_socieadad = []
        goals_scored_betis = []
        goals_scored_villarreal = []
        goals_scored_getafe = []
        goals_scored_celta = []
        goals_scored_athletic = []

        # while loop to extract goals scored by madrid in each match
        while a < 45:
            if self.main_list[a][0] == 'Madrid':
                # adds the goal score of madrid to following list
                goals_scored_madrid.append(self.main_list[a][1])
                a = a + 1
            elif self.main_list[a][2] == 'Madrid':
                # adds the goal score of madrid to following list
                goals_scored_madrid.append(self.main_list[a][3])
                a = a + 1
            else:
                a = a + 1
        # while loop to extract goals scored by barcelona in each match
        while b < 45:
            if self.main_list[b][0] == 'Barcelona':
                # adds the goal score of barcelona to following list
                goals_scored_barcelona.append(self.main_list[b][1])
                b = b + 1
            elif self.main_list[b][2] == 'Barcelona':
                # adds the goal score of barcelona to following list
                goals_scored_barcelona.append(self.main_list[b][3])
                b = b + 1
            else:
                # adds the goal score of madrid to following list
                b = b + 1
        # while loop to extract goals scored by valencia in each match
        while c < 45:
            if self.main_list[c][0] == 'Valencia':
                # adds the goal score of valencia to following list
                goals_scored_valencia.append(self.main_list[c][1])
                c = c + 1
            elif self.main_list[c][2] == 'Valencia':
                # adds the goal score of valencia to following list
                goals_scored_valencia.append(self.main_list[c][3])
                c = c + 1
            else:
                c = c + 1
        # while loop to extract goals scored by atletico in each match
        while d < 45:
            if self.main_list[d][0] == 'Atletico':
                # adds the goal score of atletico to following list
                goals_scored_atletico.append(self.main_list[d][1])
                d = d + 1
            elif self.main_list[d][2] == 'Atletico':
                # adds the goal score of atletico to following list
                goals_scored_atletico.append(self.main_list[d][3])
                d = d + 1
            else:
                d = d + 1
        # while loop to extract goals scored by socieadad in each match
        while e < 45:
            if self.main_list[e][0] == 'Socieadad':
                # adds the goal score of socieadad to following list
                goals_scored_socieadad.append(self.main_list[e][1])
                e = e + 1
            elif self.main_list[e][2] == 'Socieadad':
                # adds the goal score of socieadad to following list
                goals_scored_socieadad.append(self.main_list[e][3])
                e = e + 1
            else:
                e = e + 1
        # while loop to extract goals scored by betis in each match
        while f < 45:
            if self.main_list[f][0] == 'Betis':
                # adds the goal score of betis to following list
                goals_scored_betis.append(self.main_list[f][1])
                f = f + 1
            elif self.main_list[f][2] == 'Betis':
                # adds the goal score of betis to following list
                goals_scored_betis.append(self.main_list[f][3])
                f = f + 1
            else:
                f = f + 1
        # while loop to extract goals scored by villarreal in each match
        while g < 45:
            if self.main_list[g][0] == 'Villarreal':
                # adds the goal score of villarreal to following list
                goals_scored_villarreal.append(self.main_list[g][1])
                g = g + 1
            elif self.main_list[g][2] == 'Villarreal':
                # adds the goal score of villarreal to following list
                goals_scored_villarreal.append(self.main_list[g][3])
                g = g + 1
            else:
                g = g + 1
        # while loop to extract goals scored by getafe in each match
        while h < 45:
            if self.main_list[h][0] == 'Getafe':
                # adds the goal score of getafe to following list
                goals_scored_getafe.append(self.main_list[h][1])
                h = h + 1
            elif self.main_list[h][2] == 'Getafe':
                # adds the goal score of getafe to following list
                goals_scored_getafe.append(self.main_list[h][3])
                h = h + 1
            else:
                h = h + 1
        # while loop to extract goals scored by celta in each match
        while k < 45:
            if self.main_list[k][0] == 'Celta':
                # adds the goal score of celta to following list
                goals_scored_celta.append(self.main_list[k][1])
                k = k + 1
            elif self.main_list[k][2] == 'Celta':
                # adds the goal score of celta to following list
                goals_scored_celta.append(self.main_list[k][3])
                k = k + 1
            else:
                k = k + 1
        # while loop to extract goals scored by athletic in each match
        while l < 45:
            if self.main_list[l][0] == 'Athletic':
                # adds the goal score of athletic to following list
                goals_scored_athletic.append(self.main_list[l][1])
                l = l + 1
            elif self.main_list[l][2] == 'Athletic':
                # adds the goal score of atheltic to following list
                goals_scored_athletic.append(self.main_list[l][3])
                l = l + 1
            else:
                l = l + 1

        # converts the list value in string to integer
        for i in range(0, len(goals_scored_madrid)):
            goals_scored_madrid[i] = int(goals_scored_madrid[i])

        for i in range(0, len(goals_scored_barcelona)):
            goals_scored_barcelona[i] = int(goals_scored_barcelona[i])

        for i in range(0, len(goals_scored_valencia)):
            goals_scored_valencia[i] = int(goals_scored_valencia[i])

        for i in range(0, len(goals_scored_atletico)):
            goals_scored_atletico[i] = int(goals_scored_atletico[i])

        for i in range(0, len(goals_scored_socieadad)):
            goals_scored_socieadad[i] = int(goals_scored_socieadad[i])

        for i in range(0, len(goals_scored_betis)):
            goals_scored_betis[i] = int(goals_scored_betis[i])

        for i in range(0, len(goals_scored_villarreal)):
            goals_scored_villarreal[i] = int(goals_scored_villarreal[i])

        for i in range(0, len(goals_scored_getafe)):
            goals_scored_getafe[i] = int(goals_scored_getafe[i])

        for i in range(0, len(goals_scored_celta)):
            goals_scored_celta[i] = int(goals_scored_celta[i])

        for i in range(0, len(goals_scored_athletic)):
            goals_scored_athletic[i] = int(goals_scored_athletic[i])

        # calculate the sum of the total goals scored in the total_scored_(team) list
        total_scored_madrid = sum(goals_scored_madrid)
        total_scored_barcelona = sum(goals_scored_barcelona)
        total_scored_valencia = sum(goals_scored_valencia)
        total_scored_atletico = sum(goals_scored_atletico)
        total_scored_socieadad = sum(goals_scored_socieadad)
        total_scored_betis = sum(goals_scored_betis)
        total_scored_villarreal = sum(goals_scored_villarreal)
        total_scored_getafe = sum(goals_scored_getafe)
        total_scored_celta = sum(goals_scored_celta)
        total_scored_athletic = sum(goals_scored_athletic)

        # appends each data to listF list
        self.listF.append(total_scored_madrid)
        self.listF.append(total_scored_barcelona)
        self.listF.append(total_scored_valencia)
        self.listF.append(total_scored_atletico)
        self.listF.append(total_scored_socieadad)
        self.listF.append(total_scored_betis)
        self.listF.append(total_scored_villarreal)
        self.listF.append(total_scored_getafe)
        self.listF.append(total_scored_celta)
        self.listF.append(total_scored_athletic)

    def goals_against(self):
        # intialising each vairable for each while loop
        a = 0
        b = 0
        c = 0
        d = 0
        e = 0
        f = 0
        g = 0
        h = 0
        k = 0
        l = 0
        # creating each different empty list to add goals recieved by each different team in each match
        goals_recieved_madrid = []
        goals_recieved_barcelona = []
        goals_recieved_valencia = []
        goals_recieved_atletico = []
        goals_recieved_socieadad = []
        goals_recieved_betis = []
        goals_recieved_villarreal = []
        goals_recieved_getafe = []
        goals_recieved_celta = []
        goals_recieved_athletic = []
        # while loop to extract goals recieved by madrid in each match
        while a < 45:
            if self.main_list[a][0] == 'Madrid':
                goals_recieved_madrid.append(self.main_list[a][3])
                # adds the goal score recieved by madrid to following list
                a = a + 1
            elif self.main_list[a][2] == 'Madrid':
                # adds the goal score recieved by madrid to following list
                goals_recieved_madrid.append(self.main_list[a][1])
                a = a + 1
            else:
                a = a + 1
        # while loop to extract goals recieved by barcelona in each match
        while b < 45:
            if self.main_list[b][0] == 'Barcelona':
                # adds the goal score recieved by barcelona to following list
                goals_recieved_barcelona.append(self.main_list[b][3])
                b = b + 1
            elif self.main_list[b][2] == 'Barcelona':
                # adds the goal score recieved by barcelona to following list
                goals_recieved_barcelona.append(self.main_list[b][1])
                b = b + 1
            else:
                b = b + 1
        # while loop to extract goals recieved by valencia in each match
        while c < 45:
            if self.main_list[c][0] == 'Valencia':
                # adds the goal score recieved by valencia to following list
                goals_recieved_valencia.append(self.main_list[c][3])
                c = c + 1
            elif self.main_list[c][2] == 'Valencia':
                # adds the goal score recieved by valencia to following list
                goals_recieved_valencia.append(self.main_list[c][1])
                c = c + 1
            else:
                c = c + 1
        # while loop to extract goals recieved by atletico in each match
        while d < 45:
            # adds the goal score recieved by atletico to following list
            if self.main_list[d][0] == 'Atletico':
                goals_recieved_atletico.append(self.main_list[d][3])
                d = d + 1
            # adds the goal score recieved by atletico to following list
            elif self.main_list[d][2] == 'Atletico':
                goals_recieved_atletico.append(self.main_list[d][1])
                d = d + 1
            else:
                d = d + 1
        # while loop to extract goals recieved by socieadad in each match
        while e < 45:
            if self.main_list[e][0] == 'Socieadad':
                # adds the goal score recieved by socieadad to following list
                goals_recieved_socieadad.append(self.main_list[e][3])
                e = e + 1
            elif self.main_list[e][2] == 'Socieadad':
                # adds the goal score recieved by socieadad to following list
                goals_recieved_socieadad.append(self.main_list[e][1])
                e = e + 1
            else:
                e = e + 1
        # while loop to extract goals recieved by betis in each match
        while f < 45:
            if self.main_list[f][0] == 'Betis':
                # adds the goal score recieved by betis to following list
                goals_recieved_betis.append(self.main_list[f][3])
                f = f + 1
            elif self.main_list[f][2] == 'Betis':
                # adds the goal score recieved by betis to following list
                goals_recieved_betis.append(self.main_list[f][1])
                f = f + 1
            else:
                f = f + 1
        # while loop to extract goals recieved by villarreal in each match
        while g < 45:
            # adds the goal score recieved by villarreal to following list
            if self.main_list[g][0] == 'Villarreal':
                goals_recieved_villarreal.append(self.main_list[g][3])
                g = g + 1
                # adds the goal score recieved by villarreal to following list
            elif self.main_list[g][2] == 'Villarreal':
                goals_recieved_villarreal.append(self.main_list[g][1])
                g = g + 1
            else:
                g = g + 1
        # while loop to extract goals recieved by getafe in each match
        while h < 45:
            if self.main_list[h][0] == 'Getafe':
                # adds the goal score recieved by getafe to following list
                goals_recieved_getafe.append(self.main_list[h][3])
                h = h + 1
            elif self.main_list[h][2] == 'Getafe':
                # adds the goal score recieved by getafe to following list
                goals_recieved_getafe.append(self.main_list[h][1])
                h = h + 1
            else:
                h = h + 1
        # while loop to extract goals recieved by celta in each match
        while k < 45:
            if self.main_list[k][0] == 'Celta':
                # adds the goal score recieved by celta to following list
                goals_recieved_celta.append(self.main_list[k][3])
                k = k + 1
            elif self.main_list[k][2] == 'Celta':
                # adds the goal score recieved by celta to following list
                goals_recieved_celta.append(self.main_list[k][1])
                k = k + 1
            else:
                k = k + 1
        # while loop to extract goals recieved by atheltic in each match
        while l < 45:
            if self.main_list[l][0] == 'Athletic':
                # adds the goal score recieved by athletic to following list
                goals_recieved_athletic.append(self.main_list[l][3])
                l = l + 1
            elif self.main_list[l][2] == 'Athletic':
                # adds the goal score recieved by athletic to following list
                goals_recieved_athletic.append(self.main_list[l][1])
                l = l + 1
            else:
                l = l + 1
        # converts the list value in string to integer
        for i in range(0, len(goals_recieved_madrid)):
            goals_recieved_madrid[i] = int(goals_recieved_madrid[i])

        for i in range(0, len(goals_recieved_barcelona)):
            goals_recieved_barcelona[i] = int(goals_recieved_barcelona[i])

        for i in range(0, len(goals_recieved_valencia)):
            goals_recieved_valencia[i] = int(goals_recieved_valencia[i])

        for i in range(0, len(goals_recieved_atletico)):
            goals_recieved_atletico[i] = int(goals_recieved_atletico[i])

        for i in range(0, len(goals_recieved_socieadad)):
            goals_recieved_socieadad[i] = int(goals_recieved_socieadad[i])

        for i in range(0, len(goals_recieved_betis)):
            goals_recieved_betis[i] = int(goals_recieved_betis[i])

        for i in range(0, len(goals_recieved_villarreal)):
            goals_recieved_villarreal[i] = int(goals_recieved_villarreal[i])

        for i in range(0, len(goals_recieved_getafe)):
            goals_recieved_getafe[i] = int(goals_recieved_getafe[i])

        for i in range(0, len(goals_recieved_celta)):
            goals_recieved_celta[i] = int(goals_recieved_celta[i])

        for i in range(0, len(goals_recieved_athletic)):
            goals_recieved_athletic[i] = int(goals_recieved_athletic[i])

        # calculate the sum of the total goals recieved in the total_scored_(team) list
        total_recieved_madrid = sum(goals_recieved_madrid)
        total_recieved_barcelona = sum(goals_recieved_barcelona)
        total_recieved_valencia = sum(goals_recieved_valencia)
        total_recieved_atletico = sum(goals_recieved_atletico)
        total_recieved_socieadad = sum(goals_recieved_socieadad)
        total_recieved_betis = sum(goals_recieved_betis)
        total_recieved_villarreal = sum(goals_recieved_villarreal)
        total_recieved_getafe = sum(goals_recieved_getafe)
        total_recieved_celta = sum(goals_recieved_celta)
        total_recieved_athletic = sum(goals_recieved_celta)

        # appends each data to listF list
        self.listA.append(total_recieved_madrid)
        self.listA.append(total_recieved_barcelona)
        self.listA.append(total_recieved_valencia)
        self.listA.append(total_recieved_atletico)
        self.listA.append(total_recieved_socieadad)
        self.listA.append(total_recieved_betis)
        self.listA.append(total_recieved_villarreal)
        self.listA.append(total_recieved_getafe)
        self.listA.append(total_recieved_celta)
        self.listA.append(total_recieved_athletic)

    # creating a function to calculate difference between goals scored and goal recieved by each team
    def goal_diff(self):
        # subtracts the listF list's and listA list's corresponding index value
        difference = list(map(operator.sub, self.listF, self.listA))
        # for loop to add '+' character in front of index data the is positive
        for i in difference:
            # checks if the data inside the list in positive to equal to zero
            if i >= 0:
                # appends the data to listDiff list
                self.listDiff.append(f'+{i}')
            # if above condition is not matched
            else:
                # appends the data to listDiff list
                self.listDiff.append(i)

    # creating a function to calculate points obtained by each team
    def goal_points(self):
        # creating empty list for teams that ended up winning a match and ending the match in a draw
        win_points = []
        draw_points = []

        # for loop to multiply number of wins by a team by 3
        for m in self.listW:
            # appends the values multiplied by 3
            win_points.append(m*3)

        # for loop to append the draw points
        for n in self.listD:
            # appends the values
            draw_points.append(n)

        # adds the corresponding data of win_points list and draw_points lists
        self.listPts = list(map(operator.add, win_points, draw_points))


# creating object of class
obj = Football()
# calling all the created methods
obj.teams()
obj.result()
obj.played()
obj.won()
obj.draw()
obj.loss()
obj.goals_for()
obj.goals_against()
obj.goal_diff()
obj.goal_points()

# for loop using zip function to sort all the multiple lists' internal data according to listPts list
obj.listPts, obj.team_list, obj.listP, obj.listW, obj.listD, obj.listL, obj.listF, obj.listA, obj.listDiff = (list(t) for t in zip(
    *sorted((zip(obj.listPts, obj.team_list, obj.listP, obj.listW, obj.listD, obj.listL, obj.listF, obj.listA, obj.listDiff)), reverse=True)))

# for loop to display all the lists next to each other using zip function
for i, j, k, l, m, n, o, p, q in zip(obj.team_list, obj.listP, obj.listW, obj.listD, obj.listL, obj.listF, obj.listA, obj.listDiff, obj.listPts):
    print((f"{i:10}"), '\t', j, '\t', k, '\t',
          l, '\t', m, '\t', n, '\t', o, '\t', p, '\t', q)
