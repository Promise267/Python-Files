print("Swallow Speed Analysis: Version 1.0\n")
speed_list = []
mph_to_kph = 1.60934
entered_speed = input("Enter the Next Reading: ")
# condition to check if no readings entered.
if (entered_speed == ""):
    print("No readings entered. Nothing to do.")

# condition if the reading is entered.
else:
    # loops until no readings are entered.
    while (entered_speed != ""):
        # checks character e and appends and converts to mph
        if (entered_speed[:1].lower() == "e"):
            if(entered_speed[1:].replace('.', '', 1).isdigit()):
                print("Reading saved.")
                speed_list.append(float(entered_speed[1:])/mph_to_kph)
                entered_speed = input("Enter the Next Reading: ")
            else:
                print("Reading not saved")
                entered_speed = input("Enter the Next Reading: ")
        # checks character u and appends and converts to mph
        elif (entered_speed[:1].lower() == "u"):
            if(entered_speed[1:].replace('.', '', 1).isdigit()):
                print("Reading saved.")
                speed_list.append(float(entered_speed[1:]))
                entered_speed = input("Enter the Next Reading: ")
            else:
                print("Reading not saved.")
                entered_speed = input("Enter the Next Reading: ")
        # checks if a invalid reading is entered.
        else:
            print("Reading not saved.")
            entered_speed = input("Enter the Next Reading: ")
    # condition if readings are valid.
    if (len(speed_list) != 0):
        print("\nResults Summary\n")
        print(len(speed_list), "Readings Analysed.\n")
        # displays maximum value as MPH and KPH from the speed list.
        print("Max Speed:", format(max(speed_list), '.1f'), "MPH,",
              format((max(speed_list)*mph_to_kph), '.1f'), "KPH.")
        # dispays minimum value as MPH and KPH from the speed list.
        print("Min Speed:", format(min(speed_list), '.1f'), "MPH,",
              format((min(speed_list)*mph_to_kph), '.1f'), "KPH.")
        # displays average value as MPH and KPH from the speed list.
        total = 0
        for i in range(0, len(speed_list)):
            total = total + speed_list[i]
        average_speed = (total) / len(speed_list)
        print("Avg Speed:", format(average_speed, '.1f'), "MPH,",
              format((average_speed*mph_to_kph), '.1f'), "KPH.")
    # if no values entered
    else:
        print("No valid readings entered. Nothing to do.")
